DROP TABLE IF EXISTS user;
DROP TABLE IF EXISTS raffle;
DROP TABLE IF EXISTS ticket;

CREATE TABLE user (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    is_admin BOOLEAN DEFAULT 0
);

CREATE TABLE raffle (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    description TEXT,
    price REAL NOT NULL,
    total_numbers INTEGER NOT NULL,
    image_url TEXT,
    status TEXT DEFAULT 'active',
    type TEXT DEFAULT 'manual',
    winner_ticket_id INTEGER,
    promo_price REAL,
    promo_end TIMESTAMP,
    FOREIGN KEY (winner_ticket_id) REFERENCES ticket (id)
);

CREATE TABLE ticket (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    raffle_id INTEGER NOT NULL,
    number INTEGER, -- Nullable for pending random tickets
    status TEXT DEFAULT 'pending',
    purchase_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES user (id),
    FOREIGN KEY (raffle_id) REFERENCES raffle (id)
);
