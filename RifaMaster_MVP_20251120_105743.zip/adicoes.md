# Lista de Adições
Utilize este arquivo para listar novas funcionalidades ou adições que devem ser feitas na aplicação.
O assistente verificará este arquivo a cada interação.

## Concluídas ✅

- [x] o que deve mostrar nas opções de adição na rifa fazendinha são quantidade, não porcentagens, porcentagens é a base de cálculo para os valores mostrados

- [x] retira as setas do input de número na seleção de quantidade de rifas

- [x] adiciona um botão na tela de admin para remover promoção e para adicionar promoção

- [x] o botão de comprar mais das rifas deve levar para a respectiva rifa

- [x] corrige a lógica de mostrar o ganhador para o usuário **(CORRIGIDO: agora compara número do bilhete em vez de ID)**

- [x] colocar as rifas compradas em ordem crescente **(ORDER BY title, number ASC)**

- [x] adicionar no campo de ações na tela de admin um "botão" para remover promoção e para remover a rifa **(IMPLEMENTADO: botões com validação)**

- [x] após sortear uma rifa, fica com o valor sorteado nela, acho que é válido um botão de detalhes, que mostra todos os detalhes do ganhador **(IMPLEMENTADO: modal com detalhes completos)**

## Pendentes ⏳

- [ ] em editar rifa, altera o botão de adicionar promoção e usa o modal de promoção, mostra a promoção definida e um botão para remove-la

- [ ] Crie uma tela de perfil do usuário, onde ele possa inserir e atualizar suas informações pessoais.
Após criar a conta, o usuário deve receber um lembrete amigável para completar o preenchimento do perfil, caso deseje receber possíveis prêmios futuramente.

A tela de edição de perfil deve permitir inserir e alterar dados como:

Nome completo

Telefone

E-mail

Chave PIX

Endereço

CPF

Inclua também outros campos que você considerar úteis, desde que mantenham o formulário curto, objetivo e não invasivo, para evitar que o usuário se sinta desconfortável ou sobrecarregado ao fornecer dados pessoais.

- [] Ajusta todas as setas de input de valores, coloca um estilização melhor

- [] coloca uma logica de limitação pros valores de promoções, so pode ser inferior ao valor atual

